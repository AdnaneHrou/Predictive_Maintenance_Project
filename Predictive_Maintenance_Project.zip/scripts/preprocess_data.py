
import pandas as pd
from sklearn.preprocessing import StandardScaler
import os

def load_data(file_path):
    return pd.read_csv(file_path)

def preprocess_data(df):
    # Handling missing values
    df = df.fillna(method='ffill')
    
    # Feature scaling
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df.drop('failure', axis=1))
    df_scaled = pd.DataFrame(scaled_features, columns=df.columns[:-1])
    df_scaled['failure'] = df['failure']
    
    return df_scaled

if __name__ == "__main__":
    data_path = os.path.join('data', 'maintenance_data.csv')
    df = load_data(data_path)
    df_preprocessed = preprocess_data(df)
    df_preprocessed.to_csv(os.path.join('data', 'preprocessed_data.csv'), index=False)
