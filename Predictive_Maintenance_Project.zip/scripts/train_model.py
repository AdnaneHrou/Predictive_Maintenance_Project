
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

def load_data(file_path):
    return pd.read_csv(file_path)

def train_model(df):
    X = df.drop('failure', axis=1)
    y = df['failure']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    return model, X_test, y_test

if __name__ == "__main__":
    data_path = os.path.join('data', 'preprocessed_data.csv')
    df = load_data(data_path)
    model, X_test, y_test = train_model(df)
    
    model_path = os.path.join('models', 'predictive_maintenance_model.pkl')
    joblib.dump(model, model_path)
