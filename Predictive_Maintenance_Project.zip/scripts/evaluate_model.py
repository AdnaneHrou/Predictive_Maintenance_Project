
import pandas as pd
from sklearn.metrics import classification_report
import joblib
import os

def load_data(file_path):
    return pd.read_csv(file_path)

def load_model(model_path):
    return joblib.load(model_path)

def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    report = classification_report(y_test, predictions)
    print(report)
    return report

if __name__ == "__main__":
    data_path = os.path.join('data', 'preprocessed_data.csv')
    model_path = os.path.join('models', 'predictive_maintenance_model.pkl')
    
    df = load_data(data_path)
    model = load_model(model_path)
    
    X_test = df.drop('failure', axis=1)
    y_test = df['failure']
    
    report = evaluate_model(model, X_test, y_test)
    
    with open(os.path.join('docs', 'evaluation_report.txt'), 'w') as f:
        f.write(report)
